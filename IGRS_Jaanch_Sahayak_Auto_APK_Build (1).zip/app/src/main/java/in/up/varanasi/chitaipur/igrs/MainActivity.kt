package in.up.varanasi.chitaipur.igrs

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import in.up.varanasi.chitaipur.igrs.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            val old = b.investigation.text?.toString().orEmpty()
            b.investigation.setText((old + " " + text).trim())
        }
    }

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeech() else Toast.makeText(this, "Microphone permission आवश्यक है", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val prefs = getSharedPreferences("igrs", MODE_PRIVATE)
        b.officerName.setText(prefs.getString("officer", ""))

        b.micButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startSpeech()
            else permission.launch(Manifest.permission.RECORD_AUDIO)
        }

        b.generateButton.setOnClickListener {
            val officer=b.officerName.text.toString().trim()
            val no=b.igrsNo.text.toString().trim()
            val complainant=b.complainant.text.toString().trim()
            val complaint=b.complaint.text.toString().trim()
            val inv=b.investigation.text.toString().trim()
            if (no.isBlank() || complainant.isBlank() || inv.isBlank()) {
                Toast.makeText(this, "IGRS नं., शिकायतकर्ता और जांच विवरण भरें", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            prefs.edit().putString("officer", officer).apply()
            val opposite=if(b.oppositeStatement.isChecked) "हाँ" else "नहीं"
            val satisfied=if(b.satisfied.isChecked) "हाँ" else "नहीं"
            val report="""IGRS प्रार्थना पत्र पर जांच रिपोर्ट

A. जांचकर्ता अधिकारी का विवरण
1. नाम: $officer
2. पद: उ0नि0
3. नियुक्ति स्थान: थाना चितईपुर, कमिश्नरेट वाराणसी

B. शिकायत का विवरण
5. IGRS संदर्भ नं0: $no
7. शिकायतकर्ता का नाम व पता: $complainant
9. शिकायत का संक्षिप्त विवरण: $complaint

C. जांच का विवरण एवं कृत कार्यवाही
16. जांच का विवरण:
महोदय, प्रकरण की जांच के क्रम में उपलब्ध प्रार्थना पत्र तथा जांच के दौरान प्राप्त तथ्यों का अवलोकन किया गया। $inv

14. विपक्षी का बयान हुआ अथवा नहीं: $opposite
20. आवेदक जांच से संतुष्ट है: $satisfied

24. जांचकर्ता का हस्ताक्षर व नाम:
उ0नि0 $officer"""
            b.report.text=report
        }

        b.shareButton.setOnClickListener {
            val text=b.report.text.toString()
            val intent=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,text) }
            startActivity(Intent.createChooser(intent,"आख्या Share करें"))
        }
    }

    private fun startSpeech() {
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "जांच की कार्यवाही बोलें")
        }
        try { speech.launch(i) } catch(e:Exception) { Toast.makeText(this,"Voice input उपलब्ध नहीं",Toast.LENGTH_SHORT).show() }
    }
}