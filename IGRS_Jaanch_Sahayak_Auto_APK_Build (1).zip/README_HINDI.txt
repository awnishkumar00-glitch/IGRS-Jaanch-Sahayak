IGRS जांच सहायक — Android App Source Code v1

यह Android Studio का installable app project है।

APK बनाने के चरण:
1. Android Studio खोलें।
2. Open Project चुनें और इस extracted folder को खोलें।
3. Gradle sync पूरा होने दें।
4. Build > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

वर्तमान सुविधाएँ:
- Android native app
- Hindi voice input
- IGRS नंबर, शिकायतकर्ता और शिकायत विवरण
- जांच की कार्यवाही बोलकर/लिखकर दर्ज करना
- structured जांच आख्या बनाना
- officer name device पर save
- Share / Print workflow

अगले production version के लिए:
- Camera/PDF upload और OCR
- secure AI backend
- exact 30-field IGRS Word/PDF generation
- login and role-based access
- encrypted case database and audit log

सुरक्षा:
वर्तमान app किसी external AI API को case data नहीं भेजता।
